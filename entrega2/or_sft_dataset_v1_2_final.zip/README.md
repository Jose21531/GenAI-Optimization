# OR-SFT Dataset v1.2-final

Dataset para SFT/QLoRA de Qwen2.5-1.5B-Instruct en formulación LP/MILP paramétrica.

## Tamaño
- 1.050 ejemplos.
- 50 familias.
- 21 variantes deterministas por familia.
- 100% español.
- Targets sin solución óptima ni valor óptimo.

## Auditoría matemática
Se auditó manualmente una instancia representativa y la formulación canónica de cada una
de las 50 familias.

- 38 familias aprobadas sin cambios.
- 12 familias corregidas.
- 3 correcciones sustantivas.
- 9 correcciones menores.
- 0 errores estructurales tras la corrección.
- 0 duplicados exactos.

Las correcciones se documentan en `AUDIT_50.md`, `canonical_audit_50.csv` y
`canonical_audit_50.json`.

## Controles adicionales
- F43 (CVRP): capacidad regenerada con una partición factible conocida; fallos=0.
- F49 (unit commitment): condiciones iniciales construidas a partir de un schedule LP factible;
  fallos=0.
- Split de desarrollo por familias: 840 train / 210 validation.
- Pilot: 200 ejemplos, 4 por familia.
- Auditoría de similitud textual con benchmark externo: {'max': 0.26972499328207783, 'mean_of_max': 0.08563409662106763, 'p95_of_max': 0.20213956781682832, 'count_over_0_60': 0, 'count_over_0_70': 0}.

## Archivos
- `or_sft_1050_messages_v1_2.jsonl`: dataset completo listo para chat-SFT.
- `or_sft_1050_rich_v1_2.jsonl`: versión rica con metadatos y hashes.
- `or_sft_train_840_family_split_v1_2.jsonl`: desarrollo, 40 familias.
- `or_sft_val_210_family_split_v1_2.jsonl`: desarrollo, 10 familias no vistas.
- `or_sft_pilot_200_v1_2.jsonl`: piloto balanceado.
- `manual_review_50_v1_2.jsonl`: una muestra por familia.
- `family_catalog_v1_2.json`: catálogo canónico.
- `AUDIT_50.md`, `canonical_audit_50.csv`, `canonical_audit_50.json`: auditoría.

## Uso recomendado
1. Pilot QLoRA con 200 ejemplos para verificar que el entrenamiento y el enmascarado del loss
   funcionan.
2. Desarrollo con 840/210 por familias para elegir configuración.
3. Una vez congelados los hiperparámetros, reentrenar el adapter final con los 1.050 ejemplos.
4. Evaluar una sola vez sobre el benchmark oficial de 30 problemas con FOM-5 v2.
