# Auditoría matemática de 50 formulaciones canónicas — v1.2-final

- Familias auditadas: **50**
- Aprobadas sin cambios: **38**
- Corregidas: **12**
- Correcciones sustantivas: **3**
- Correcciones menores: **9**
- Errores estructurales posteriores: **0**
- Duplicados exactos: **0**
- Fallos de factibilidad F43: **0**
- Fallos de factibilidad F49: **0**

## Familias corregidas

| Familia | Severidad | Hallazgo | Corrección |
|---|---|---|---|
| F12 — assignment | menor | La consigna dice que cada trabajador realiza como máximo una tarea; la etiqueta usaba igualdad. | Cambiar la restricción por Σ_j x_ij ≤ 1. |
| F30 — multi_period_production_inventory | menor | La etiqueta usa inventario inicial I_p0, pero el enunciado no lo especificaba. | Añadir inventario inicial cero al enunciado. |
| F31 — capacitated_lot_sizing | menor | La etiqueta usa I_0, pero el enunciado no lo especificaba. | Añadir inventario inicial cero al enunciado. |
| F32 — inventory_with_backorders | menor | La etiqueta usa I_0 y B_0, pero el enunciado no los especificaba. | Añadir inventario y atraso iniciales iguales a cero. |
| F33 — fixed_charge_transportation | menor | La formulación introducía un Big-M sin definir cómo obtenerlo. | Definir M_ij=min{s_i,d_j}, una cota válida y ajustada. |
| F42 — traveling_salesman_mtz | menor | Las restricciones MTZ usaban un nodo r que no estaba declarado. | Declarar r como nodo de referencia fijo arbitrario. |
| F43 — capacitated_vehicle_routing | sustantivo | El texto indicaba vehículos disponibles, mientras la etiqueta obligaba a usar exactamente K. | Modelar como máximo K rutas y ajustar la capacidad generada para garantizar factibilidad. |
| F44 — single_machine_weighted_tardiness | menor | La notación i<j presupone un orden fijo sobre las tareas. | Explicitar que P contiene una representación de cada par no ordenado. |
| F46 — job_shop_scheduling | menor | El conjunto de conflictos podía interpretarse con ambos órdenes del mismo par. | Definir una sola representación por par no ordenado de operaciones conflictivas. |
| F47 — project_scheduling_disjunctive_resource | menor | El conjunto de conflictos podía interpretarse con ambos órdenes del mismo par. | Definir una sola representación por par no ordenado de actividades conflictivas. |
| F48 — battery_dispatch | sustantivo | El enunciado mencionaba eficiencias y estado inicial sin dar sus valores ni aclarar la relajación continua. | Añadir η_c, η_d, E_0 y hacer explícita la ausencia de exclusividad binaria carga/descarga. |
| F49 — unit_commitment_simplified | sustantivo | Se usaba u_g0 y p_g,t-1 sin especificar completamente las condiciones iniciales; la factibilidad de rampa no estaba garantizada. | Añadir u_g0 y p_g0 numéricos construidos desde un schedule factible y declarar p_g0 en parámetros. |

## Criterio de aprobación

Se revisó correspondencia entre enunciado y formulación, dimensionalidad de variables, sentido y términos del objetivo, completitud de restricciones, dominios, símbolos declarados, condiciones de borde, uso de Big-M, consistencia temporal/de red y factibilidad por construcción en las familias que podían quedar inviables por datos aleatorios.
